#include<iostream>
using namespace std;
int main()
{
	int arr[]={10,20,30};
	int n=3;
	int key;{
	cout<<"enter element to search:"<<endl;
	cin>>key;
	}
	int index = 1;
	int newvalue = 50;
	arr[index]=newvalue;
	for(int i=0;i<3;i++){
		cout<<arr[i]<<" "<<endl;
	}
	return 0;
}