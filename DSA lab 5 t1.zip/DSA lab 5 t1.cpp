#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* prev;
    Node* next;
};

Node* head=NULL;

// insert at end (for creating list)
void insertEnd(int val)
{
    Node* newNode=new Node();
    newNode->data=val;
    newNode->next=NULL;
    newNode->prev=NULL;

    if(head==NULL)
    {
        head=newNode;
        return;
    }

    Node* temp=head;

    while(temp->next!=NULL)
        temp=temp->next;

    temp->next=newNode;
    newNode->prev=temp;
}

// insert at beginning
void addBeginning(int val)
{
    Node* newNode=new Node();
    newNode->data=val;

    newNode->next=head;
    newNode->prev=NULL;

    if(head!=NULL)
        head->prev=newNode;

    head=newNode;
}

// insert after 45
void addAfter45(int val)
{
    Node* temp=head;

    while(temp!=NULL && temp->data!=45)
        temp=temp->next;

    if(temp==NULL)
    {
        cout<<"45 not found\n";
        return;
    }

    Node* newNode=new Node();
    newNode->data=val;

    newNode->next=temp->next;
    newNode->prev=temp;

    if(temp->next!=NULL)
        temp->next->prev=newNode;

    temp->next=newNode;
}

// delete beginning
void deleteBeginning()
{
    if(head==NULL)
        return;

    Node* temp=head;

    head=head->next;

    if(head!=NULL)
        head->prev=NULL;

    delete temp;
}

// delete node after 45
void deleteAfter45()
{
    Node* temp=head;

    while(temp!=NULL && temp->data!=45)
        temp=temp->next;

    if(temp==NULL || temp->next==NULL)
    {
        cout<<"No node after 45\n";
        return;
    }

    Node* del=temp->next;

    temp->next=del->next;

    if(del->next!=NULL)
        del->next->prev=temp;

    delete del;
}

// display
void display()
{
    Node* temp=head;

    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }

    cout<<endl;
}

int main()
{
    int n,val;

    cout<<"Enter number of nodes: ";
    cin>>n;

    cout<<"Enter values:\n";

    for(int i=0;i<n;i++)
    {
        cin>>val;
        insertEnd(val);
    }

    cout<<"List: ";
    display();

    addBeginning(10);
    cout<<"After insert at beginning: ";
    display();

    addAfter45(50);
    cout<<"After insert after 45: ";
    display();

    deleteBeginning();
    cout<<"After delete beginning: ";
    display();

    deleteAfter45();
    cout<<"After delete after 45: ";
    display();

    return 0;
}