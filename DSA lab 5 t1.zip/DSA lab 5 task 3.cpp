#include<iostream>
using namespace std;

struct Player
{
    string name;
    int score;
    Player* prev;
    Player* next;
};

Player* head=NULL;

//insert sorted
void addPlayer(string name,int score)
{
    Player* newNode=new Player();
    newNode->name=name;
    newNode->score=score;
    newNode->next=NULL;
    newNode->prev=NULL;

    if(head==NULL || score < head->score)
    {
        newNode->next=head;
        if(head!=NULL)
            head->prev=newNode;
        head=newNode;
        return;
    }

    Player* temp=head;

    while(temp->next!=NULL && temp->next->score < score)
        temp=temp->next;

    newNode->next=temp->next;

    if(temp->next!=NULL)
        temp->next->prev=newNode;

    temp->next=newNode;
    newNode->prev=temp;
}

void deletePlayer(string name)
{
    Player* temp=head;

    while(temp!=NULL && temp->name!=name)
        temp=temp->next;

    if(temp==NULL)
        return;

    if(temp->prev!=NULL)
        temp->prev->next=temp->next;
    else
        head=temp->next;

    if(temp->next!=NULL)
        temp->next->prev=temp->prev;

    delete temp;
}

void display()
{
    Player* temp=head;

    while(temp!=NULL)
    {
        cout<<temp->name<<" "<<temp->score<<endl;
        temp=temp->next;
    }
}

void lowestScore()
{
    if(head!=NULL)
        cout<<"Lowest Score Player: "<<head->name<<" "<<head->score<<endl;
}

void sameScore(int score)
{
    Player* temp=head;

    while(temp!=NULL)
    {
        if(temp->score==score)
            cout<<temp->name<<" "<<temp->score<<endl;

        temp=temp->next;
    }
}

int main()
{
    int choice,score;
    string name;

    while(true)
    {
        cout<<"\n1 Add Player\n2 Delete Player\n3 Display\n4 Lowest Score\n5 Same Score\n6 Exit\n";
        cin>>choice;

        if(choice==1)
        {
            cout<<"Enter name: ";
            cin>>name;

            cout<<"Enter score: ";
            cin>>score;

            addPlayer(name,score);
        }

        else if(choice==2)
        {
            cout<<"Enter player name: ";
            cin>>name;

            deletePlayer(name);
        }

        else if(choice==3)
        {
            display();
        }

        else if(choice==4)
        {
            lowestScore();
        }

        else if(choice==5)
        {
            cout<<"Enter score: ";
            cin>>score;

            sameScore(score);
        }

        else
            break;
    }

    return 0;
}