#include <iostream>
using namespace std;

int main() {
    int rows, coloumns;

    
    cout << "Enter number of rows: "<<endl;
    cin >> rows;

    cout << "Enter number of coloumns: "<<endl;
    cin >> coloumns;

    
    int** matrix = new int*[rows];

    for (int i = 0; i < rows; i++) {
        matrix[i] = new int[coloumns];
    }

    
    cout << "\nEnter elements of the matrix:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < coloumns; j++) {
            cin >> matrix[i][j];
        }
    }

    cout << "\nMatrix is:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < coloumns; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }

    for (int i = 0; i < rows; i++) {
        delete[] matrix[i];
    }

    delete[] matrix;

    return 0;
}
