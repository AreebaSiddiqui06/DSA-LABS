#include <iostream>
#include <string>
using namespace std;

struct Mobile {
    string brand;
    int units;
    float price;
    Mobile* next;
};

Mobile* head = nullptr;

void addMobile() {

    Mobile* newMobile = new Mobile;

    cout << "\nEnter Brand Name: ";
    cin >> newMobile->brand;

    cout << "Enter Units in Stock: ";
    cin >> newMobile->units;

    cout << "Enter Price: ";
    cin >> newMobile->price;

    newMobile->next = nullptr;

    // If list is empty
    if (head == nullptr) {
        head = newMobile;
    }
    else {
        Mobile* temp = head;

        while (temp->next != nullptr) {
            temp = temp->next;
        }

        temp->next = newMobile;
    }

    cout << "\nMobile added successfully!\n";
}

void deleteMobile() {

    if (head == nullptr) {
        cout << "\nInventory is empty.\n";
        return;
    }

    string brandName;
    cout << "\nEnter Brand Name to delete: ";
    cin >> brandName;

    Mobile* temp = head;
    Mobile* prev = nullptr;

    // If first node matches
    if (temp != nullptr && temp->brand == brandName) {
        head = temp->next;
        delete temp;
        cout << "\nMobile deleted successfully!\n";
        return;
    }

    // Search in list
    while (temp != nullptr && temp->brand != brandName) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "\nMobile not found.\n";
        return;
    }

    prev->next = temp->next;
    delete temp;

    cout << "\nMobile deleted successfully!\n";
}

void displayMobiles() {

    if (head == nullptr) {
        cout << "\nInventory is empty.\n";
        return;
    }

    Mobile* temp = head;

    cout << "\n==================================";
    cout << "\n        MOBILE INVENTORY";
    cout << "\n==================================\n";

    while (temp != nullptr) {

        cout << "Brand : " << temp->brand << endl;
        cout << "Units : " << temp->units << endl;
        cout << "Price : " << temp->price << endl;
        cout << "----------------------------------\n";

        temp = temp->next;
    }
}

int main() {

    int choice;

    do {

        cout << "\n==================================";
        cout << "\n   MOBILE INVENTORY MANAGEMENT";
        cout << "\n==================================";
        cout << "\n1. Add Mobile";
        cout << "\n2. Delete Mobile";
        cout << "\n3. Display Mobiles";
        cout << "\n4. Exit";
        cout << "\n----------------------------------";
        cout << "\nEnter your choice: ";

        cin >> choice;

        switch (choice) {

            case 1:
                addMobile();
                break;

            case 2:
                deleteMobile();
                break;

            case 3:
                displayMobiles();
                break;

            case 4:
                cout << "\nExiting program...\n";
                break;

            default:
                cout << "\nInvalid choice!\n";
        }

    } while (choice != 4);

    return 0;
}