#include <iostream>
#include <string>
using namespace std;

struct Profile {
    string username;
    string bio;
    int age;
    Profile* next;
};

Profile* head = nullptr;

void createProfile() {

    Profile* newProfile = new Profile;

    cout << "\nEnter Username: ";
    cin >> newProfile->username;

    cout << "Enter Age: ";
    cin >> newProfile->age;

    cout << "Enter Bio: ";
    cin.ignore();
    getline(cin, newProfile->bio);

    newProfile->next = nullptr;

    if (head == nullptr) {
        head = newProfile;
    }
    else {
        Profile* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newProfile;
    }

    cout << "\nProfile created successfully!\n";
}

void updateProfile() {

    if (head == nullptr) {
        cout << "\nNo profiles available.\n";
        return;
    }

    string name;
    cout << "\nEnter Username to update: ";
    cin >> name;

    Profile* temp = head;

    while (temp != nullptr && temp->username != name) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "\nProfile not found.\n";
        return;
    }

    cout << "\nEnter New Age: ";
    cin >> temp->age;

    cout << "Enter New Bio: ";
    cin.ignore();
    getline(cin, temp->bio);

    cout << "\nProfile updated successfully!\n";
}

void deleteProfile() {

    if (head == nullptr) {
        cout << "\nNo profiles available.\n";
        return;
    }

    string name;
    cout << "\nEnter Username to delete: ";
    cin >> name;

    Profile* temp = head;
    Profile* prev = nullptr;

    if (temp != nullptr && temp->username == name) {
        head = temp->next;
        delete temp;
        cout << "\nProfile deleted successfully!\n";
        return;
    }

    while (temp != nullptr && temp->username != name) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "\nProfile not found.\n";
        return;
    }

    prev->next = temp->next;
    delete temp;

    cout << "\nProfile deleted successfully!\n";
}

void searchProfile() {

    if (head == nullptr) {
        cout << "\nNo profiles available.\n";
        return;
    }

    string name;
    cout << "\nEnter Username to search: ";
    cin >> name;

    Profile* temp = head;

    while (temp != nullptr && temp->username != name) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "\nProfile not found.\n";
        return;
    }

    cout << "\n==================================";
    cout << "\n        PROFILE FOUND";
    cout << "\n==================================\n";

    cout << "Username : " << temp->username << endl;
    cout << "Age      : " << temp->age << endl;
    cout << "Bio      : " << temp->bio << endl;
}

void viewProfiles() {

    if (head == nullptr) {
        cout << "\nNo profiles available.\n";
        return;
    }

    Profile* temp = head;

    cout << "\n==================================";
    cout << "\n        ALL PROFILES";
    cout << "\n==================================\n";

    while (temp != nullptr) {

        cout << "Username : " << temp->username << endl;
        cout << "Age      : " << temp->age << endl;
        cout << "Bio      : " << temp->bio << endl;
        cout << "----------------------------------\n";

        temp = temp->next;
    }
}

int main() {

    int choice;

    do {

        cout << "\n==================================";
        cout << "\n   SOCIAL MEDIA PROFILE SYSTEM";
        cout << "\n==================================";
        cout << "\n1. Create Profile";
        cout << "\n2. Update Profile";
        cout << "\n3. Delete Profile";
        cout << "\n4. Search Profile";
        cout << "\n5. View All Profiles";
        cout << "\n6. Exit";
        cout << "\n----------------------------------";
        cout << "\nEnter your choice: ";

        cin >> choice;

        switch (choice) {

            case 1:
                createProfile();
                break;

            case 2:
                updateProfile();
                break;

            case 3:
                deleteProfile();
                break;

            case 4:
                searchProfile();
                break;

            case 5:
                viewProfiles();
                break;

            case 6:
                cout << "\nExiting program...\n";
                break;

            default:
                cout << "\nInvalid choice!\n";
        }

    } while (choice != 6);

    return 0;
}