#include <iostream>
using namespace std;

class Queue {
	static const int SIZE = 5;
    int arr[SIZE];
    int front, rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    bool isEmpty() {
        return (front == -1 || front > rear);
    }

    void enqueue(int value) {
        if (rear == SIZE - 1) {
            cout << "Overflow\n";
            return;
        }
        if (front == -1) front = 0;
        arr[++rear] = value;
    }

    int count() {
        if (isEmpty()) return 0;
        return (rear - front + 1);
    }
};

int main() {
    Queue q;

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);

    cout << "Number of elements: " << q.count();

    return 0;
}