#include <iostream>
using namespace std;

int main() {
    int numbers[5] = {10, 20, 30, 40, 50};

    int *ptr = numbers;  // Pointer to the first element

    cout << "Array elements using pointer:\n";

    for (int i = 0; i < 5; i++) {
        cout << *(ptr + i) << endl;   
    }

    return 0;
}