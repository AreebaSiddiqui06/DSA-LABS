#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* last = NULL;

void insertBefore(int value) {
    Node* temp = new Node();
    temp->data = value;

    if (last == NULL) {
        last = temp;
        temp->next = temp;
    } else {
        temp->next = last->next;
        last->next = temp;
    }
}

void insertAfter(int value) {
    Node* temp = new Node();
    temp->data = value;

    if (last == NULL) {
        last = temp;
        temp->next = temp;
    } else {
        temp->next = last->next;
        last->next = temp;
        last = temp;
    }
}

void deleteNode(int key) {
    if (last == NULL) {
        cout << "List empty\n";
        return;
    }

    Node *curr = last->next, *prev = last;

    do {
        if (curr->data == key) {

        
            if (curr == last && curr->next == last) {
                last = NULL;
            }
           
            else if (curr == last->next) {
                prev->next = curr->next;
                last->next = curr->next;
            }
           
            else if (curr == last) {
                prev->next = curr->next;
                last = prev;
            }
           
            else {
                prev->next = curr->next;
            }

            delete curr;
            cout << "Deleted\n";
            return;
        }

        prev = curr;
        curr = curr->next;

    } while (curr != last->next);

    cout << "Not found\n";
}


void display() {
    if (last == NULL) {
        cout << "List empty\n";
        return;
    }

    Node* temp = last->next;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != last->next);

    cout << endl;
}

int main() {
    insertBefore(10);
    insertBefore(5);
    insertAfter(20);

    display();

    deleteNode(10);
    display();

    return 0;
}