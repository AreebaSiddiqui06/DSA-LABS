#include <iostream>
using namespace std;

class Book {
public:
    string id, name, author, isbn;
    double price;
};

struct Node {
    Book b;
    Node* next;
};

Node* last = NULL;

void addBook(Book b) {
    Node* temp = new Node();
    temp->b = b;

    if (last == NULL) {
        last = temp;
        temp->next = temp;
    } else {
        temp->next = last->next;
        last->next = temp;
        last = temp;
    }
}

void printBooks() {
    if (last == NULL) return;

    Node* temp = last->next;
    do {
        cout << temp->b.id << " " << temp->b.name << endl;
        temp = temp->next;
    } while (temp != last->next);
}

void printBook(string id) {
    Node* temp = last->next;
    do {
        if (temp->b.id == id) {
            cout << "Found: " << temp->b.name << endl;
            return;
        }
        temp = temp->next;
    } while (temp != last->next);

    cout << "Not found\n";
}

void removeBook(string id) {
    Node *curr = last->next, *prev = last;

    do {
        if (curr->b.id == id) {
            prev->next = curr->next;
            if (curr == last) last = prev;

            delete curr;
            cout << "Deleted\n";
            return;
        }
        prev = curr;
        curr = curr->next;
    } while (curr != last->next);
}

void updateBook(string id, string name) {
    Node* temp = last->next;

    do {
        if (temp->b.id == id) {
            temp->b.name = name;
            cout << "Updated\n";
            return;
        }
        temp = temp->next;
    } while (temp != last->next);
}

int main() {
    Book b1 = {"1","C++","Ali","111",500};
    Book b2 = {"2","DSA","Ahmed","222",600};

    addBook(b1);
    addBook(b2);

    printBooks();

    removeBook("1");
    printBooks();

    updateBook("2","OOP");
    printBooks();

    return 0;
}